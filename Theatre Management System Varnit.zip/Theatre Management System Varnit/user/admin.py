from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(MyUser)
admin.site.register(MovieTheater)
admin.site.register(MovieName)
admin.site.register(MovieTicket)